import Mathlib.Tactic
import TokenRelative.Observe
import TokenRelative.Stability
import TokenRelative.ZeroEmergence

/-!
# TokenRelative.Geometry — 方向的几何: 未锁定方向 → 位置漂移 → 数字多义

用户结论 (2026-08-14, 几何角度): 0 自身的方向、后继的方向、后继迭代的方向,
如果未经声明式锁定, 必将导致抵达不同的位置, 产生不同的数字。

推演:
  1. 位置 = 标签化结构状态。0 的载体 (单互锁对) 有 6 个标签化实例,
     后继 1 的载体 (完美匹配) 有 3 个标签化实例 — 位置多重。
  2. 若方向未经声明式锁定 (方向不承载于结构), 位置无法确定:
     任意两个单锁对同构, 无结构差异可声明方向 → 抵达位置不定。
  3. 位置不定 → 同一数字对应多个位置 → 数字多义。
  4. 锁定 (声明式) 唯一形式 = 互锁边 (Successor.S1: 模型无方向关系);
     互锁边无方向 (Successor.S2) → 方向不可锁定 → 漂移不可消除。
-/

namespace TokenRelative.Geometry

open TokenRelative.Observe
open TokenRelative.Stability
open TokenRelative.ZeroEmergence

-- ============================================================
-- G1: 0 的位置多重性
-- ============================================================

/--
定理 G1: 0 的载体 (单互锁对) 有 6 个标签化位置 —
6 条候选边各是一个位置。若方向未锁定, "0 的位置" 不确定。
-/
theorem zero_positions_multiplicity :
    (allStates.filter (fun s => IsSingleLock s)).length = 6 := by
  native_decide

-- ============================================================
-- G2: 1 的位置多重性
-- ============================================================

/--
定理 G2: 后继 1 的载体 (完美匹配) 有 3 个标签化位置 —
从 0 的后继方向未锁定时, "1 的位置" 有 3 个候选。
-/
theorem one_positions_multiplicity :
    perfectMatchings4.length = 3 := by
  rw [perfectMatchings4_eq]
  native_decide

-- ============================================================
-- G3: 位置不可锁定 — 无结构差异可声明方向
-- ============================================================

/--
定理 G3: 0 的所有位置同构 (唯一同构类) —
标签化位置之间无结构差异, 无法通过结构声明方向/锁定位置。
-/
theorem zero_positions_unlockable :
    (computeReps.filter (fun s => IsSingleLock s)).length = 1 := by
  exact single_lock_class_unique

-- ============================================================
-- G4: 核心 — 未锁定方向 → 位置多重 → 数字多义
-- ============================================================

/--
定理 G4: 方向未经声明式锁定 → 同一数字对应多个位置 (数字多义) —
  ① 0 有 6 个位置 (G1), 1 有 3 个位置 (G2);
  ② 位置间无结构差异可锁定 (G3) — 方向不承载于结构;
  ③ 未锁定 → 抵达位置不定 → 不同位置产生不同数字。
-/
theorem direction_unlocked_positions_diverge :
    -- ① 0 的位置多重 (6)
    (allStates.filter (fun s => IsSingleLock s)).length = 6 ∧
    -- ② 1 的位置多重 (3)
    perfectMatchings4.length = 3 ∧
    -- ③ 位置不可锁定 (唯一同构类)
    (computeReps.filter (fun s => IsSingleLock s)).length = 1 := by
  constructor
  · native_decide
  · constructor
    · rw [perfectMatchings4_eq]
      native_decide
    · exact single_lock_class_unique

end TokenRelative.Geometry
