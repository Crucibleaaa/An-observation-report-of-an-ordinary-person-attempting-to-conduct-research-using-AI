import Mathlib.Tactic
import TokenRelative.Observe
import TokenRelative.Stability

/-!
# TokenRelative.Successor — 后继方向与正交性假设

用户结论 (2026-08-14): 自然数的后继 — 假设的基点本身无状态;
承载信息的结构必须是破缺状态才可能产生 (T006);
因此不能假设后继方向与基点 0 的自指方向正交;
事实上由于数学空间无限维度的特性, 后继无法稳定迭代。

推演:
  1. 基点无状态: 对象全同, 方向只能是结构的属性 (破缺), 不是对象属性 —
     单互锁对交换端点同构, 自指无内在方向
  2. 承载信息必须破缺 (T006): 后继要承载 "第 n 个" 信息, 本身必须破缺
  3. 正交假设需要第二关系类型 (方向关系/有向边):
     模型只有无向互锁 (所有边为规范无序对 a ≤ b) → 正交不可表达
  4. 有限模型: 禁多锁 (度 ≤ 1) 下边数 ∈ {0,1,2};
     完美匹配 (2 边) 无合法后继 → 迭代有界, 最多 2 步
  5. 无限维: 每步需选择新方向, 所有方向同构无规范 → 后继不稳定 (未形式化, 见 claim)
-/

namespace TokenRelative.Successor

open TokenRelative.Observe
open TokenRelative.Stability

-- ============================================================
-- S1: 模型无方向 — 所有边是规范无序对
-- ============================================================

/--
定理 S1: 模型内不存在方向关系 — 所有互锁边都是规范无序对 (a ≤ b)。
正交方向需要第二种关系类型 (有向边), 不在状态空间中。
-/
theorem no_direction_in_state :
    ∀ s ∈ allStates, ∀ e ∈ s, e.1 ≤ e.2 := by
  native_decide

-- ============================================================
-- S2: 自指无内在方向 — 任意两个互锁对同构
-- ============================================================

/--
定理 S2: 单互锁对无方向性 — 任意两个互锁对同构 (方向不可区分)。
0 的自指方向不是对象的属性; 若有方向, 它来自破缺结构而非基点。
-/
theorem lock_pair_undirected :
    Isomorphic ([(0, 1)] : State) ([(2, 3)] : State) := by
  native_decide

-- ============================================================
-- S3: 禁多锁下边数有界 — 可用的互锁对有限
-- ============================================================

/-- 合法状态 (Bool): 禁多锁 (每对象至多一条边)。 -/
def Legal (s : State) : Bool :=
  (List.finRange 4).all (fun v => decide (degree s v ≤ 1))

/-- 完美匹配 (Bool): 每对象度 = 1 (2 对互锁, 稳定结构)。 -/
def IsPerfect (s : State) : Bool :=
  (List.finRange 4).all (fun v => decide (degree s v = 1))

/--
定理 S3: 4 对象禁多锁下, 边数 ∈ {0,1,2} —
可用互锁对资源有限: 最多 2 对 (完美匹配)。
-/
theorem edge_count_bounded :
    allStates.all (fun s =>
      !Legal s || s.length == 0 || s.length == 1 || s.length == 2) = true := by
  native_decide

-- ============================================================
-- S4: 完美匹配无合法后继 — 迭代有界
-- ============================================================

/--
定理 S4: 完美匹配 (2 边, 度全 1) 不存在合法后继 —
没有任何合法状态边数更多 (禁多锁下 2 已是最大)。
后继迭代到完美匹配即停止: 无法稳定迭代。
-/
theorem perfect_no_successor :
    allStates.all (fun s =>
      !IsPerfect s ||
        !(allStates.any (fun t => Legal t && decide (s.length < t.length)))) = true := by
  native_decide

-- ============================================================
-- S5: 存在后继当且仅当边数 < 2
-- ============================================================

/--
定理 S5: 合法后继 (边数 + 1) 存在 ⟺ 边数 < 2。
从 0 的载体 (1 边, 互逆结构) 恰好一步到完美匹配 (2 边), 之后无后继。
-/
theorem successor_exists_iff_below_two :
    allStates.all (fun s =>
      !Legal s ||
        ((allStates.any (fun t => Legal t && decide (t.length = s.length + 1))) ==
          decide (s.length < 2))) = true := by
  native_decide

-- ============================================================
-- S6: 核心组合 — 后继不能正交, 迭代有界
-- ============================================================

/--
定理 S6: 后继正交假设在模型中不可表达, 且迭代有界 —
  ① 模型无方向关系: 所有边为规范无序对 (S1), 任意互锁对同构 (S2);
     正交方向 (与自指独立的第二维) 需要方向关系, 模型内不存在;
  ② 禁多锁下边数 ∈ {0,1,2} (S3), 完美匹配无合法后继 (S4);
     后继链 1 边 → 2 边即止, 无第三步 — 有限模型内后继无法稳定迭代。
-/
theorem successor_cannot_orthogonal :
    -- ① 无方向: 模型状态空间只有无向互锁
    (allStates.all (fun s => s.all (fun e => decide (e.1 ≤ e.2)))) = true ∧
    -- ② 迭代有界: 完美匹配 (2 边) 无合法后继
    (allStates.all (fun s =>
      !IsPerfect s ||
        !(allStates.any (fun t => Legal t && decide (s.length < t.length)))) = true) := by
  constructor
  · native_decide
  · native_decide

end TokenRelative.Successor
