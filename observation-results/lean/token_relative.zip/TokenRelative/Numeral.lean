import Mathlib.Tactic
import TokenRelative.Observe
import TokenRelative.Stability
import TokenRelative.ZeroEmergence
import TokenRelative.Geometry

/-!
# TokenRelative.Numeral — 数字定义与数值分离

用户结论 (2026-08-14): 数字本身的定义应当与数值分离。基于基点漂移理论,
每一个新的数字: 数值变化、位置不变。数字的定义必须将每个数字都视为一个
完整的无限维度的基点, 重新声明方向后, 才能定义。

推演:
  1. 数字 (身份) ≠ 数值 (位置/量):
     数字 = 结构身份 (同构类); 数值 = 标签化位置 (T008: 位置多重)。
     同一数字身份对应多个数值位置 → 二者分离。
  2. 基点漂移: 每个新数字 = 新基点。数值 (身份序号) 变化,
     位置 (基点内部自指结构) 不变 — 所有基点结构同构。
  3. 方向不承载于结构 (T007 S1/S2, T008 G3):
     数字不能由结构单独确定 → 必须将每个数字视为完整无限维基点,
     重新声明方向后才可定义。
-/

namespace TokenRelative.Numeral

open TokenRelative.Observe
open TokenRelative.Stability
open TokenRelative.ZeroEmergence
open TokenRelative.Geometry

-- ============================================================
-- D1: 数字身份与数值分离
-- ============================================================

/--
定理 D1: 同一数字身份 (同构类) 对应多个数值 (标签化位置) —
数字 (身份) 与数值 (位置) 是分离的概念: 数字 ≠ 数值。
-/
theorem numeral_value_separation :
    ∃ s t : State,
      IsSingleLock s ∧ IsSingleLock t ∧ Isomorphic s t ∧ s ≠ t := by
  refine ⟨[(0, 1)], [(0, 2)], ?_, ?_, ?_, ?_⟩
  · native_decide
  · native_decide
  · native_decide
  · native_decide

-- ============================================================
-- D2: 基点结构不变 — 所有基点自指结构同构
-- ============================================================

/--
定理 D2: 所有基点 (互逆结构) 的内部自指结构同构 —
数值变化 (身份不同), 位置不变 (基点结构相同)。
-/
theorem base_structure_invariant :
    (allStates.filter (fun s => IsSingleLock s)).all
      (fun s => (allStates.filter (fun t => IsSingleLock t)).all
        (fun t => decide (Isomorphic s t))) = true := by
  native_decide

-- ============================================================
-- D3: 结构不足以确定数字 — 需重新声明方向
-- ============================================================

/--
定理 D3: 结构不足以确定数值 —
同一同构类 (同一结构身份) 内含多个标签化位置, 结构无法区分它们。
数字必须由结构之外的声明 (方向声明) 定义。
-/
theorem structure_not_determine_value :
    -- 单锁对: 结构身份唯一 (1 类) 但位置多重 (6)
    (computeReps.filter (fun s => IsSingleLock s)).length = 1 ∧
    (allStates.filter (fun s => IsSingleLock s)).length = 6 := by
  constructor
  · exact single_lock_class_unique
  · exact zero_positions_multiplicity

-- ============================================================
-- D4: 核心组合 — 数字 = 基点 + 重新声明方向
-- ============================================================

/--
定理 D4: 数字定义与数值分离, 数字须作为完整基点重新声明方向 —
  ① 数字 (同构类) ≠ 数值 (位置): 同一身份多位置 (D1);
  ② 基点结构不变: 所有互逆结构同构 (D2) — 数值变化、位置不变;
  ③ 结构不足以确定数字 (D3): 身份唯一但位置多重,
     数字须由基点 + 方向声明定义, 不能由结构单独给出。
-/
theorem numeral_needs_direction :
    -- ① 同一数字身份, 多个数值位置
    (∃ s t : State, IsSingleLock s ∧ IsSingleLock t ∧ Isomorphic s t ∧ s ≠ t) ∧
    -- ② 基点结构不变 (所有互逆结构同构)
    ((allStates.filter (fun s => IsSingleLock s)).all
      (fun s => (allStates.filter (fun t => IsSingleLock t)).all
        (fun t => decide (Isomorphic s t))) = true) ∧
    -- ③ 结构不足: 身份唯一 ∧ 位置多重
    ((computeReps.filter (fun s => IsSingleLock s)).length = 1 ∧
     (allStates.filter (fun s => IsSingleLock s)).length = 6) := by
  constructor
  · exact numeral_value_separation
  · constructor
    · exact base_structure_invariant
    · exact structure_not_determine_value

end TokenRelative.Numeral
