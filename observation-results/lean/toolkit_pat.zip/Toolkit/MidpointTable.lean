/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Data.Real.Basic
import Mathlib.Analysis.Real.Sqrt
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

/-!
# Toolkit/MidpointTable — the table midpoint is a memory/compute tradeoff: N* = sqrt(c/s)

Self-contained (imports mathlib only; no project dependencies).

The phase-converter table (RulerMiddle hypothesis 1) has a size choice `N`
(precision grid size). The cost model:

  total cost C(N) = s·N + c/N

where `s` = memory unit cost (storage), `c` = compute unit cost (compensation
computation for a coarse table). The optimal midpoint is N* = √(c/s), driven
entirely by hardware parameters (RulerMidpoint).

Main theorems:

1. `cost_at_sqrt`: the cost at N = √(c/s) is 2·√(s·c) — the minimal cost
   (AM-GM: s·N + c/N ≥ 2√(s·c)).
2. `cost_minimal_at_sqrt`: N* = √(c/s) minimizes the cost: for any other N,
   the cost is at least the cost at the midpoint. Proof via AM-GM
   (`sq_le_sq`-free: `a + b ≥ 2·√(a·b)` for a = s·N, b = c/N).
3. `midpoint_depends_on_hardware`: the midpoint N* = √(c/s) is determined by
   the hardware parameters s (memory) and c (compute) — the same mathematical
   structure has different optimal tables on different hardware.
-/

noncomputable section

namespace MidpointToolkit

/-! ## The cost model

`C(N) = s·N + c/N`: memory cost grows with table size, compute cost shrinks
(coarse table needs compensation computation). -/

/-- Total cost of a table of size N: memory `s·N` plus compute `c/N`. -/
def totalCost (s c N : ℝ) : ℝ := s * N + c / N

/-- **Cost at the midpoint is minimal** (AM-GM): for any N > 0,
`s·N + c/N ≥ 2·√(s·c)`, with equality at N = √(c/s). The midpoint minimizes
the cost. -/
lemma cost_minimal_at_sqrt (s c N : ℝ) (hs : 0 < s) (hc : 0 < c)
    (hN : 0 < N) :
    2 * Real.sqrt (s * c) ≤ totalCost s c N := by
  unfold totalCost
  -- AM-GM via squares: (√(sN) - √(c/N))² ≥ 0
  have hsq : 0 ≤ (Real.sqrt (s * N) - Real.sqrt (c / N)) ^ 2 := sq_nonneg _
  -- hmul: sN · (c/N) = sc
  have hmul : s * N * (c / N) = s * c := by
    field_simp [ne_of_gt hN]
  -- hprod: √(sN)·√(c/N) = √(sc) (both sides nonneg, squares equal)
  have hprod : Real.sqrt (s * N) * Real.sqrt (c / N) = Real.sqrt (s * c) := by
    have hsq1 : (Real.sqrt (s * N) * Real.sqrt (c / N)) ^ 2 = (Real.sqrt (s * c)) ^ 2 := by
      have h1 : (Real.sqrt (s * N)) ^ 2 = s * N := Real.sq_sqrt (by positivity)
      have h2 : (Real.sqrt (c / N)) ^ 2 = c / N := Real.sq_sqrt (by positivity)
      have h3 : (Real.sqrt (s * c)) ^ 2 = s * c := Real.sq_sqrt (by positivity)
      rw [mul_pow, h1, h2, h3, hmul]
    have hnonneg1 : 0 ≤ Real.sqrt (s * N) * Real.sqrt (c / N) := by positivity
    have hnonneg2 : 0 ≤ Real.sqrt (s * c) := by positivity
    -- both nonneg with equal squares ⟹ equal
    have hle1 : Real.sqrt (s * N) * Real.sqrt (c / N) ≤ Real.sqrt (s * c) := by
      exact le_of_sq_le_sq (le_of_eq hsq1) hnonneg2
    have hle2 : Real.sqrt (s * c) ≤ Real.sqrt (s * N) * Real.sqrt (c / N) := by
      exact le_of_sq_le_sq (le_of_eq hsq1.symm) hnonneg1
    exact le_antisymm hle1 hle2
  -- expand the square: (a-b)² = a² + b² - 2ab
  have hsq2 : 2 * Real.sqrt (s * N) * Real.sqrt (c / N) ≤ s * N + c / N := by
    have h1 : (Real.sqrt (s * N)) ^ 2 = s * N := Real.sq_sqrt (by positivity)
    have h2 : (Real.sqrt (c / N)) ^ 2 = c / N := Real.sq_sqrt (by positivity)
    have hsq3 : 0 ≤ (Real.sqrt (s * N)) ^ 2 + (Real.sqrt (c / N)) ^ 2 -
        2 * Real.sqrt (s * N) * Real.sqrt (c / N) := by
      have habs : (Real.sqrt (s * N) - Real.sqrt (c / N)) ^ 2 =
          (Real.sqrt (s * N)) ^ 2 + (Real.sqrt (c / N)) ^ 2 -
          2 * Real.sqrt (s * N) * Real.sqrt (c / N) := by ring
      rwa [habs] at hsq
    rw [h1, h2] at hsq3
    linarith
  -- replace √(sN)·√(c/N) by √(sc)
  have hfinal : 2 * Real.sqrt (s * c) ≤ s * N + c / N := by
    have hsq2' : 2 * (Real.sqrt (s * N) * Real.sqrt (c / N)) ≤ s * N + c / N := by
      nlinarith
    rwa [hprod] at hsq2'
  exact hfinal

lemma cost_equals_bound_at_sqrt (s c : ℝ) (hs : 0 < s) (hc : 0 < c) :
    totalCost s c (Real.sqrt (c / s)) = 2 * Real.sqrt (s * c) := by
  unfold totalCost
  -- s·√(c/s) + c/√(c/s) = 2·√(s·c): each term = √(s·c)
  have h1 : s * Real.sqrt (c / s) = Real.sqrt (s * c) := by
    have hcs : 0 ≤ c / s := by positivity
    rw [← Real.sqrt_sq (by positivity : 0 ≤ s * Real.sqrt (c / s))]
    rw [← Real.sqrt_sq (by positivity : 0 ≤ Real.sqrt (s * c))]
    congr 1
    -- (s·√(c/s))² = s²·(c/s) = s·c = √(sc)²
    have h1a : (s * Real.sqrt (c / s)) ^ 2 = s * c := by
      have hsq1 : (Real.sqrt (c / s)) ^ 2 = c / s := Real.sq_sqrt hcs
      rw [mul_pow, hsq1]
      field_simp [ne_of_gt hs]
    have h1b : (Real.sqrt (s * c)) ^ 2 = s * c := Real.sq_sqrt (by positivity)
    rw [h1a, h1b]
  have h2 : c / Real.sqrt (c / s) = Real.sqrt (s * c) := by
    have hcs : 0 ≤ c / s := by positivity
    have hsqrt_pos : Real.sqrt (c / s) ≠ 0 := by
      exact ne_of_gt (Real.sqrt_pos.mpr (div_pos hc hs))
    -- c / √(c/s) = c · √(s/c) = √(s·c)  (via squaring, both nonneg)
    have hnonneg1 : 0 ≤ c / Real.sqrt (c / s) := by positivity
    have hnonneg2 : 0 ≤ Real.sqrt (s * c) := by positivity
    have hsq2a : (c / Real.sqrt (c / s)) ^ 2 = s * c := by
      field_simp [hsqrt_pos]
      have hsq1 : (Real.sqrt (c / s)) ^ 2 = c / s := Real.sq_sqrt hcs
      rw [hsq1]
      field_simp [ne_of_gt hs]
    have hsq2b : (Real.sqrt (s * c)) ^ 2 = s * c := Real.sq_sqrt (by positivity)
    have hle1 : c / Real.sqrt (c / s) ≤ Real.sqrt (s * c) := by
      exact le_of_sq_le_sq (by rw [hsq2a, hsq2b]) hnonneg2
    have hle2 : Real.sqrt (s * c) ≤ c / Real.sqrt (c / s) := by
      exact le_of_sq_le_sq (by rw [hsq2b, hsq2a]) hnonneg1
    exact le_antisymm hle1 hle2
  rw [h1, h2]
  ring

/-- **The midpoint depends on hardware**: N* = √(c/s) is determined entirely
by the hardware parameters s (memory cost) and c (compute cost). The same
mathematical structure has different optimal table sizes on different
hardware: fast memory (small s) permits a larger table. -/
lemma midpoint_depends_on_hardware (s₁ c₁ s₂ c₂ : ℝ)
    (hs₁ : 0 < s₁) (hc₁ : 0 < c₁) (hs₂ : 0 < s₂) (hc₂ : 0 < c₂) :
    Real.sqrt (c₁ / s₁) ≤ Real.sqrt (c₂ / s₂) ↔ c₁ / s₁ ≤ c₂ / s₂ := by
  -- sqrt is monotone on nonneg
  have h2 : 0 ≤ c₂ / s₂ := by positivity
  exact Real.sqrt_le_sqrt_iff h2

end MidpointToolkit
