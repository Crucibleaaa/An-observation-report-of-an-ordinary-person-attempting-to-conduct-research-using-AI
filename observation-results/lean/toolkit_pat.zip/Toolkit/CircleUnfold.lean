/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Data.Real.Basic
import Mathlib.Data.Complex.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

/-!
# Toolkit/CircleUnfold — unfolding the circle: self-similar dissection, error decay, logarithmic truncation

Self-contained (imports mathlib only; no project dependencies).

After compactification draws divergence into the circle (RulerFold: 无损保留,
contracting structure), using the circle requires *unfolding* it — dissecting
the circle into arcs. This dissection is infinitely nested (each arc scales to
the full circle), so fast approximation needs truncation.

Main theorems:

1. `arc_scales_to_circle`: self-similarity — `n` arcs of the dissection, each
   rescaled, reconstruct the full circle: `n * (2π/n) = 2π`. Every arc is a
   scaled copy of the circle (the infinite nesting).

2. `polygon_error_bound`: the dissection error of an n-gon is bounded by
   `(π/n)²/2` — the error decays like `1/n²` (each doubling of n divides the
   error by ~4; 2 bits per level). Uses mathlib `one_sub_sq_div_two_le_cos`.

3. `truncation_depth`: to approximate the circle within error ε it suffices
   to dissect to a depth with `n ≥ π/√(2ε)` — i.e. depth `k ≈ log₂(1/ε)`.
   Logarithmic-depth truncation: unfolding stops after logarithmically many
   levels, never recursing infinitely (same as the token reference-layer cut
   `[x]` stopping at one level).
-/

noncomputable section

namespace CircleUnfoldToolkit

/-! ## Self-similarity of the dissection

Unfolding the circle into `n` arcs: each arc has length `2π/n`; rescaling by
`n` reconstructs the full circle. Hence every arc is a scaled copy of the
circle — the dissection is infinitely nested. -/

/-- The dissection is self-similar: `n` arcs of length `2π/n` rescaled
reconstruct the full circle `2π`. (Each arc is a scaled copy of the circle —
unfolding is infinitely nested.) -/
lemma arc_scales_to_circle (n : ℕ) (hn : n ≠ 0) :
    (n : ℝ) * (2 * Real.pi / n) = 2 * Real.pi := by
  field_simp [hn]

/-! ## Error decay of the dissection

The n-gon dissection error is `1 - cos(π/n)`: the maximum deviation of a
polygon vertex from the circle. We bound it by `(π/n)²/2` — quadratic decay. -/

/-- Polygon dissection error: `1 - cos(π/n)` for an n-gon inscribed in the
circle. -/
def polygonError (n : ℕ) : ℝ := 1 - Real.cos (Real.pi / n)

/-- **Error bound**: the dissection error is at most `(π/n)²/2`. The error
decays quadratically in `1/n` (each doubling of n divides the error by ~4 —
2 bits per level). -/
lemma polygon_error_bound (n : ℕ) (hn : 0 < n) :
    polygonError n ≤ (Real.pi / n) ^ 2 / 2 := by
  unfold polygonError
  -- 1 - cos x ≤ x²/2 for x = π/n (from mathlib one_sub_sq_div_two_le_cos,
  -- which is a section lemma for the current variable x)
  -- one_sub_sq_div_two_le_cos has implicit x : ℝ (mathlib Bounds)
  have h : 1 - (Real.pi / n) ^ 2 / 2 ≤ Real.cos (Real.pi / n) :=
    Real.one_sub_sq_div_two_le_cos
  linarith

/-- **Error goes to zero**: for any target error ε > 0 there is a dissection
depth whose polygon error is below ε. (Existence via Archimedean: choose n
large; error ≤ (π/n)²/2 → 0.) This is the logarithmic-truncation guarantee —
no infinite recursion is needed. -/
lemma truncation_depth (ε : ℝ) (hε : 0 < ε) :
    ∃ n : ℕ, 0 < n ∧ polygonError n ≤ ε := by
  -- choose n with (π/n)²/2 ≤ ε, i.e. n ≥ π/√(2ε); Archimedean gives such n
  have harch : ∃ m : ℕ, (m : ℝ) ≥ Real.pi / Real.sqrt (2 * ε) :=
    exists_nat_ge (Real.pi / Real.sqrt (2 * ε))
  rcases harch with ⟨m, hm⟩
  let n := max m 1
  refine ⟨n, ?_, ?_⟩
  · simp [n]
  · have hn : 0 < n := by simp [n]
    have hb := polygon_error_bound n hn
    -- (π/n)²/2 ≤ ε since n ≥ m ≥ π/√(2ε)
    have hnge : (n : ℝ) ≥ (m : ℝ) := by simp [n]
    have hn_ge : (n : ℝ) ≥ Real.pi / Real.sqrt (2 * ε) := le_trans hm hnge
    have hden : 0 < Real.sqrt (2 * ε) := by positivity
    have hnR : (0 : ℝ) < (n : ℝ) := by positivity
    have hle : Real.pi / (n : ℝ) ≤ Real.sqrt (2 * ε) := by
      -- π/n ≤ √(2ε) from n ≥ π/√(2ε): cross-multiply (all positive)
      rw [div_le_iff₀ hnR]
      -- need π ≤ n·√(2ε); from π/√(2ε) ≤ n multiply by √(2ε) > 0
      have hπ : Real.pi ≤ (n : ℝ) * Real.sqrt (2 * ε) := (div_le_iff₀ hden).mp hn_ge
      rw [mul_comm] at hπ
      exact hπ
    have hsq : (Real.pi / (n : ℝ)) ^ 2 ≤ 2 * ε := by
      have hnonneg : 0 ≤ Real.pi / (n : ℝ) := by positivity
      have hden2 : 0 ≤ Real.sqrt (2 * ε) := le_of_lt hden
      -- square both sides of hle (both nonneg)
      have hsq1 : (Real.pi / (n : ℝ)) ^ 2 ≤ (Real.sqrt (2 * ε)) ^ 2 := by
        have habs : |Real.pi / (n : ℝ)| ≤ |Real.sqrt (2 * ε)| := by
          rw [abs_of_nonneg hnonneg, abs_of_nonneg hden2]
          exact hle
        exact sq_le_sq.mpr habs
      have hsqrt : (Real.sqrt (2 * ε)) ^ 2 = 2 * ε := by
        have h2e : 0 ≤ 2 * ε := by positivity
        rw [Real.sq_sqrt h2e]
      nlinarith
    have hbnd : (Real.pi / (n : ℝ)) ^ 2 / 2 ≤ ε := by nlinarith
    exact le_trans hb hbnd

end CircleUnfoldToolkit
