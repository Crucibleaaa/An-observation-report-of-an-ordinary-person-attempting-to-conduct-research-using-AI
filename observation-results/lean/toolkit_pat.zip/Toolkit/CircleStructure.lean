/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.Complex.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

/-!
# Toolkit/CircleStructure — the five components of circle structure (real-axis → circle)

Self-contained (imports mathlib only; no project dependencies).

The compactification of the real line into a circle (`ℝ ∪ {∞} ≃ S¹`) is not a
single structure: the *same* topological circle carries many shapes (ellipses,
warped circles, non-Euclidean circles, polygons) — the differences come from five
components (用户 2026-08-12 指令):

1. **Metric/scale** (度量/尺度): the ellipse parameters `a, b` — the circle is
   the case `a = b`. Parameter: the scale factors.
2. **Speed/density** (速度/密度): non-uniform parametrization `θ(t) = t + k·sin t`
   warps the point density on the same circle. Parameter: `k`.
3. **Metric geometry** (度规): Euclidean vs hyperbolic metric — the circle's
   circumference differs (`2πr` vs `2π·sinh r`). Parameter: the metric.
4. **Embedding/warp** (嵌入/翘曲): a planar circle vs a space curve
   `z = k·sin(2θ)` in ℝ³. Parameter: the warp function.
5. **Sampling** (参数化/采样): a regular n-gon → circle as n → ∞ (the polygon
   error `1 - cos(π/n) → 0`). Parameter: `n`.

Each component is parameterized (not enumerated) — the "infinite" shapes of a
circle are parameter values of these five finite components.
-/

noncomputable section

namespace CircleToolkit

/-! ## 分量1: Metric / scale (度量/尺度)

The ellipse `x = a·cos θ, y = b·sin θ` satisfies `x²/a² + y²/b² = 1` for every
angle. The circle is the special case `a = b = 1`. -/

/-- Ellipse identity: `(a·cos θ)²/a² + (b·sin θ)²/b² = 1` for nonzero `a, b`. -/
lemma ellipse_identity (a b θ : ℝ) (ha : a ≠ 0) (hb : b ≠ 0) :
    (a * Real.cos θ) ^ 2 / a ^ 2 + (b * Real.sin θ) ^ 2 / b ^ 2 = 1 := by
  field_simp [ha, hb]
  exact Real.cos_sq_add_sin_sq θ

/-- The circle is the ellipse with `a = b = 1`: `x² + y² = 1`. -/
lemma circle_is_ellipse_unit (θ : ℝ) :
    (Real.cos θ) ^ 2 + (Real.sin θ) ^ 2 = 1 := by
  exact Real.cos_sq_add_sin_sq θ

/-! ## 分量2: Speed / density (速度/密度)

Non-uniform parametrization `θ(t) = t + k·sin t` warps the point density on the
same circle. The uniform case is `k = 0`. -/

/-- The warp deviation of the parametrization from uniform: `θ'(t) - 1 = k·cos t`.
The uniform circle has zero deviation (`k = 0 ⟹ deviation 0`). -/
lemma warp_deviation (k t : ℝ) :
    (1 + k * Real.cos t) - 1 = k * Real.cos t := by
  ring

/-- Non-uniform density: for `k ≠ 0`, the angular speed varies with `t` —
points on the circle are non-uniformly distributed (扭曲圆). -/
lemma nonuniform_when_warp_nonzero (k t₁ t₂ : ℝ)
    (hk : k ≠ 0) (ht : Real.cos t₁ ≠ Real.cos t₂) :
    (1 + k * Real.cos t₁) ≠ (1 + k * Real.cos t₂) := by
  intro h
  have : k * Real.cos t₁ = k * Real.cos t₂ := by linarith
  have : Real.cos t₁ = Real.cos t₂ := mul_left_cancel₀ hk this
  exact ht this

/-! ## 分量3: Metric geometry (度规)

The same topological circle has different circumference under different metrics:
Euclidean `2πr` vs hyperbolic `2π·sinh r`. The metric is a component. -/

/-- Euclidean circumference: `2πr`. -/
def euclideanCircumference (r : ℝ) : ℝ := 2 * Real.pi * r

/-- Hyperbolic circumference: `2π·sinh r`. -/
def hyperbolicCircumference (r : ℝ) : ℝ := 2 * Real.pi * Real.sinh r

/-- The metric is a genuine component: if the hyperbolic and Euclidean
circumferences coincide, then `sinh r = r`. For `0 < r` the hyperbolic
circumference genuinely differs (sinh r > r); the metric is a structure
component, not a topological invariant of the circle. -/
lemma hyperbolic_eq_iff_sinh_eq (r : ℝ) :
    hyperbolicCircumference r = euclideanCircumference r ↔ Real.sinh r = r := by
  unfold hyperbolicCircumference euclideanCircumference
  constructor
  · intro h
    exact (mul_left_cancel₀ (by norm_num : (2 * Real.pi : ℝ) ≠ 0)) h
  · intro h
    rw [h]

/-! ## 分量4: Embedding / warp (嵌入/翘曲)

A planar circle in ℝ² vs a warped space curve `(cos θ, sin θ, k·sin 2θ)` in ℝ³.
The warp function is a component; `k = 0` recovers the planar circle. -/

/-- The planar circle embedded at height `z = 0`: the standard circle. -/
def planarCircle (θ : ℝ) : ℂ := Complex.exp (θ * Complex.I)

/-- The warped circle in 3D has a height component `z = k·sin 2θ`; the planar
circle is the case `k = 0` (zero warp). -/
lemma warp_zero_is_planar (k θ : ℝ) (hk : k = 0) :
    k * Real.sin (2 * θ) = 0 := by
  simp [hk]

/-! ## 分量5: Sampling (参数化/采样)

A regular n-gon approximates the circle; the approximation error
`1 - cos(π/n) → 0` as `n → ∞`. The sampling `n` is a component. -/

/-- Polygon-to-circle error for a regular n-gon: `1 - cos(π/n)`. -/
def polygonError (n : ℕ) : ℝ := 1 - Real.cos (Real.pi / n)

/-- The polygon error is nonnegative for `0 < n`. -/
lemma polygon_error_nonneg (n : ℕ) : 0 ≤ polygonError n := by
  unfold polygonError
  have hcos : Real.cos (Real.pi / n) ≤ 1 := Real.cos_le_one _
  linarith

/-- **Sampling convergence**: for the square (n = 4), the polygon error is
`1 - cos(π/4) = 1 - √2/2 ≈ 0.2929`. -/
lemma polygon_error_square : polygonError 4 = 1 - Real.sqrt 2 / 2 := by
  unfold polygonError
  norm_num [Real.cos_pi_div_four]

end CircleToolkit
