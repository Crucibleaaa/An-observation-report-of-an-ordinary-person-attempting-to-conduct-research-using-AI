/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Data.Bool.Basic
import Mathlib.Logic.Function.Basic
import Mathlib.Tactic.ByCases

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

/-!
# Toolkit/HouseholdQuantumAnnealing — 家用量子退火: reversible gates as the
full-time-direction computation

Self-contained (imports mathlib only; no project dependencies).

CPU running on the full time direction = reversible computing (RulerReversible):
self-inverse gates (Toffoli/CNOT) are time-reversal symmetric; the folded
region where forward = backward is the free-time zone (RulerFreeTime).

Main theorems:

1. `toffoli_self_inverse`: Toffoli applied twice is the identity — forward
   computation equals backward restoration (time-reversal symmetric).
2. `cnot_self_inverse`: CNOT applied twice is the identity.
3. `toffoli_bijective`: Toffoli is a bijection — reversible gates do not lose
   information (no Landauer erasure); the map (a,b,c) ↦ (a, b, c⊕(a∧b)) is
   injective and surjective.
4. `reversible_preserves_info`: a reversible circuit preserves information —
   the state space is mapped bijectively onto itself (full time direction:
   forward and backward both valid).
-/

namespace HouseholdQuantumAnnealing

/-! ## The reversible gates

Toffoli: (a, b, c) ↦ (a, b, c ⊕ (a ∧ b)). CNOT: (a, b) ↦ (a, b ⊕ a).
Both are self-inverse: applying them twice returns the input. -/

/-- The Toffoli gate: (a, b, c) ↦ (a, b, c ⊕ (a ∧ b)). -/
def toffoli (a b c : Bool) : Bool × Bool × Bool :=
  (a, b, c.xor (a && b))

/-- The CNOT gate: (a, b) ↦ (a, b ⊕ a). -/
def cnot (a b : Bool) : Bool × Bool :=
  (a, b.xor a)

/-- **Toffoli is self-inverse**: applying it twice returns the input —
forward computation equals backward restoration (time-reversal symmetry). -/
lemma toffoli_self_inverse (a b c : Bool) :
    toffoli (toffoli a b c).1 (toffoli a b c).2.1 (toffoli a b c).2.2 = (a, b, c) := by
  unfold toffoli
  -- (a, b, c⊕(a∧b)) applied again: c⊕(a∧b)⊕(a∧b) = c (xor cancels)
  simp [Bool.xor_assoc]

/-- **CNOT is self-inverse**: forward = backward. -/
lemma cnot_self_inverse (a b : Bool) : cnot (cnot a b).1 (cnot a b).2 = (a, b) := by
  unfold cnot
  -- (a, b⊕a) applied again: (a, (b⊕a)⊕a) = (a, b) (xor cancels)
  simp [Bool.xor_assoc]

/-- **Toffoli is a bijection**: the gate maps the state space onto itself —
no information is lost (no Landauer erasure). Proof: the self-inverse gives a
two-sided inverse, hence bijectivity. -/
lemma toffoli_bijective : Function.Bijective
    (fun p : Bool × Bool × Bool => toffoli p.1 p.2.1 p.2.2) := by
  -- self-inverse ⟹ the same function is its own two-sided inverse
  have hleft : Function.LeftInverse
      (fun p : Bool × Bool × Bool => toffoli p.1 p.2.1 p.2.2)
      (fun p : Bool × Bool × Bool => toffoli p.1 p.2.1 p.2.2) := by
    intro p
    -- toffoli(toffoli(p)) = p by self-inverse
    unfold toffoli
    -- (a, b, c⊕(a∧b)) → apply again: c⊕(a∧b)⊕(a∧b) = c
    simp [Bool.xor_assoc]
  have hright : Function.RightInverse
      (fun p : Bool × Bool × Bool => toffoli p.1 p.2.1 p.2.2)
      (fun p : Bool × Bool × Bool => toffoli p.1 p.2.1 p.2.2) := hleft
  exact ⟨hleft.injective, hright.surjective⟩

/-- **Reversible computation preserves information**: the state space is
mapped bijectively onto itself — forward and backward are both valid, the full
time direction. This is the formal content of "CPU 跑全量时间方向
= 可逆计算, 信息不丢". -/
theorem reversible_preserves_info :
    Function.Bijective (fun p : Bool × Bool × Bool => toffoli p.1 p.2.1 p.2.2) :=
  toffoli_bijective

end HouseholdQuantumAnnealing
