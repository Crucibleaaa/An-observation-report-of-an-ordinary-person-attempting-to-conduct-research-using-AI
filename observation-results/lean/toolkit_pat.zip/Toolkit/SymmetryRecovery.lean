/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.GroupTheory.Perm.Sign
import Mathlib.GroupTheory.Perm.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

/-!
# Toolkit/SymmetryRecovery — recover the basepoint displacement from ±1 sign projections

Self-contained (imports mathlib only; no project dependencies).

A *symmetry* is a permutation σ of a basepoint space (a pointed structure whose
basepoint is a degree of freedom). Each symmetry carries a ±1 projection: its
parity `Perm.sign σ ∈ {+1, -1}` — whether it preserves or reverses orientation.

The basepoint-teleport problem (穿折越): given a family of symmetries {σ_i} and
their observed ±1 sign projections {s_i}, recover the basepoint displacement
`delta` — the permutation by which the basepoint must be teleported so that the
signs match the observation.

Concretely: the observed sign of symmetry `σ_i` *after* the basepoint is moved by
`delta` is `Perm.sign (σ_i * delta)` (composition). The recovery problem is to
find `delta` such that

  ∀ i, Perm.sign (σ_i * delta) = s_i.

We formalize:

1. `SignProjection`: the ±1 projection of a permutation.
2. `Recovers delta`: a permutation `delta` matches the observed signs.
3. `signRecovery_mul`: the sign of a composition is the product of signs —
   the ±1 projection is a homomorphism, so the observation vector is determined by
   `sign(delta)` and the symmetries' own signs.
4. `recovery_by_sign`: if all symmetries are odd/even with known sign, the
   observation pins down `sign(delta)` — the basepoint displacement's parity is
   recovered from the sign vector.

The parity of `delta` (the basepoint's orientation class) is the recoverable
"symmetry direction"; the specific permutation is the basepoint-dependent codomain
(analogue of C007: D(H) is basepoint-independent, the concrete G_e drifts).
-/

noncomputable section

namespace SymmetryToolkit

variable {α : Type*} [Fintype α] [DecidableEq α]

/-! ## ±1 sign projections

The parity of a permutation is its ±1 projection: `+1` if it preserves
orientation (even), `-1` if it reverses (odd). -/

/-- The ±1 projection of a permutation: its parity in the unit group ℤˣ. -/
def signProjection (σ : Equiv.Perm α) : ℤˣ :=
  Equiv.Perm.sign σ

/-- A permutation's sign is ±1 (well-formed projection). -/
lemma sign_is_pm_one (σ : Equiv.Perm α) : signProjection σ = 1 ∨ signProjection σ = -1 := by
  unfold signProjection
  -- Perm.sign : Perm α → ℤˣ, and units of ℤ are ±1
  exact Int.units_eq_one_or (Equiv.Perm.sign σ)

/-- The ±1 projection is multiplicative: sign(σ * τ) = sign σ * sign τ. -/
lemma sign_mul (σ τ : Equiv.Perm α) :
    signProjection (σ * τ) = signProjection σ * signProjection τ := by
  unfold signProjection
  exact Equiv.Perm.sign_mul σ τ

/-! ## Basepoint recovery

The basepoint is moved by a displacement permutation `delta`. After the move, the
observed sign of symmetry `σ` is `sign(σ * delta)`. -/

/-- The observed sign of symmetry `σ` after the basepoint is displaced by `delta`. -/
def observedSign (σ delta : Equiv.Perm α) : ℤˣ :=
  signProjection (σ * delta)

/-- A displacement `delta` *recovers* the basepoint: it makes every symmetry's
observed sign match the given sign vector `s`. -/
def Recovers (σs : ι → Equiv.Perm α) (s : ι → ℤˣ) (delta : Equiv.Perm α) : Prop :=
  ∀ i, observedSign (σs i) delta = s i

/-- The observed sign of `σ` after displacement by `delta` factors into the sign
of `σ` and the sign of `delta`: the observation determines the basepoint
displacement's parity through `sign(delta) = s · sign(σ)`. -/
lemma observedSign_eq_mul (σ delta : Equiv.Perm α) :
    observedSign σ delta = signProjection σ * signProjection delta := by
  unfold observedSign
  rw [sign_mul]

/-- **Recovery of the basepoint parity**: if a displacement `delta` recovers the
observed signs `s`, then `sign(delta) = s_i * sign(σ_i)` for each i — the
basepoint displacement's parity (orientation class) is pinned down by any single
symmetry's observation. -/
theorem recovery_pins_parity (σ : Equiv.Perm α) (s : ℤˣ) (delta : Equiv.Perm α)
    (h : observedSign σ delta = s) :
    signProjection delta = s * signProjection σ := by
  have h' := h
  rw [observedSign_eq_mul] at h'
  -- sign σ * sign delta = s ⟹ sign delta = s * sign σ (unit group, sign σ = ±1)
  have hσ : signProjection σ = 1 ∨ signProjection σ = -1 := sign_is_pm_one σ
  rcases hσ with hσ1 | hσn
  · rw [hσ1] at h'
    -- 1 * sign delta = s ⟹ sign delta = s = s * 1
    have : signProjection delta = s := by simpa using h'
    rwa [hσ1, mul_one]
  · rw [hσn] at h'
    -- -1 * sign delta = s ⟹ sign delta = -s = s * (-1)
    have hs : -signProjection delta = s := by
      simpa using h'
    have htarget : signProjection delta = s * signProjection σ := by
      rw [hσn]
      -- s * (-1) = -s; and sign delta = -s (from hs: -sign delta = s)
      have : signProjection delta = s * (-1 : ℤˣ) := by
        -- s = -sign delta ⟹ -s = sign delta; and s * (-1) = -s
        exact hs.symm ▸ (by ext; simp)
      simpa using this
    exact htarget

/-- **The sign vector determines the basepoint parity class**: two symmetries with
the same sign observe the same displacement parity up to their own parity. If all
symmetries are even (sign = +1), then any recovering displacement is even —
recovering the basepoint from even symmetries yields an orientation-preserving
(basepoint-parity +1) teleport. -/
theorem recovery_of_even_symmetries [Nonempty ι] (σs : ι → Equiv.Perm α)
    (h_even : ∀ i, signProjection (σs i) = 1) (delta : Equiv.Perm α)
    (h_rec : Recovers σs (fun _ => (1 : ℤˣ)) delta) :
    signProjection delta = 1 := by
  -- pick some i: observedSign σs_i delta = 1 = sign σs_i * sign delta = 1 * sign delta
  rcases ‹Nonempty ι› with ⟨i⟩
  have hobs : observedSign (σs i) delta = 1 := h_rec i
  rw [observedSign_eq_mul] at hobs
  rw [h_even i] at hobs
  -- 1 * sign delta = 1 ⟹ sign delta = 1
  simpa using hobs

end SymmetryToolkit
