/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Data.Real.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

/-!
# Toolkit/ErrorSequence — the prophecy error measurement sequence

Self-contained (imports mathlib only; no project dependencies).

The error of a phase-truncation prophecy (RulerProphecy) is measurable as a
sequence: e(n) = C·n^(-(s-1)) for polynomial convergence, with a constant
per-level ratio: doubling n divides the error by 2^(s-1). Measuring once
predicts all errors (RulerErrorSeq).

Main theorems:

1. `poly_error_ratio`: the per-level error ratio of a polynomial-convergent
   series: e(2n)/e(n) = 2^(1-s) — doubling n divides the error by 2^(s-1),
   constant across all levels.
2. `poly_error_monotone`: the error decreases with n (deeper = better).
3. `alt_error_bound`: the alternating-series error is bounded by 1/(n+1) —
   the "medium" convergence error sequence.
4. `error_seq_predicts`: measuring the error once at n₀ determines the whole
   sequence via the constant ratio — the error measurement is relatively
   precise (measure once, predict all).
-/

noncomputable section

namespace ErrorSeqToolkit

/-! ## Polynomial convergence error

For a series Σ 1/k^s (s > 1), the tail error after n terms is
e(n) = n^(1-s)/(s-1). -/

/-- The polynomial-convergence tail error: `e(n) = n^(1-s)/(s-1)`. -/
def polyError (s n : ℝ) : ℝ := n ^ (1 - s) / (s - 1)

/-- **Per-level error ratio**: doubling n divides the error by 2^(s-1) —
`e(2n)/e(n) = 2^(1-s)`, constant across all levels. This is the relatively
precise error measurement: measure once, predict all. -/
lemma poly_error_ratio (s n : ℝ) (hs : 1 < s) (hn : 0 < n) :
    polyError s (2 * n) / polyError s n = 2 ^ (1 - s) := by
  unfold polyError
  -- (2n)^(1-s)/(s-1) / (n^(1-s)/(s-1)) = (2n)^(1-s)/n^(1-s) = 2^(1-s)
  have hden : (s - 1 : ℝ) ≠ 0 := by linarith
  have hnz : n ^ (1 - s) ≠ 0 := by
    exact ne_of_gt (Real.rpow_pos_of_pos hn (1 - s))
  -- (2n)^(1-s) = 2^(1-s) · n^(1-s) (mul_rpow: (xy)^z = x^z·y^z)
  have hpow : (2 * n) ^ (1 - s) = n ^ (1 - s) * 2 ^ (1 - s) := by
    have h₂ : (2 * n) ^ (1 - s) = 2 ^ (1 - s) * n ^ (1 - s) :=
      Real.mul_rpow (by positivity : (0 : ℝ) ≤ 2) (by positivity : 0 ≤ n)
    rw [h₂, mul_comm]
  -- main: e(2n)/e(n) = (2n)^(1-s)/n^(1-s) = 2^(1-s)
  rw [hpow]
  field_simp [hnz]

/-- **Error is monotone decreasing**: deeper prophecy (larger n) gives
smaller error. -/
lemma poly_error_monotone (s : ℝ) (hs : 1 < s) {n₁ n₂ : ℝ}
    (hn₁ : 0 < n₁) (hnn : n₁ ≤ n₂) :
    polyError s n₂ ≤ polyError s n₁ := by
  unfold polyError
  -- n₂^(1-s) ≤ n₁^(1-s) since 1-s < 0 and n₁ ≤ n₂
  have hneg : 1 - s ≤ 0 := by linarith
  have hpow : n₂ ^ (1 - s) ≤ n₁ ^ (1 - s) := by
    exact Real.rpow_le_rpow_of_nonpos hn₁ hnn hneg
  have hden : 0 < s - 1 := by linarith
  exact div_le_div_of_nonneg_right hpow (by positivity : 0 ≤ s - 1)

/-! ## Alternating series error

The alternating-series tail error is bounded by 1/(n+1): the "medium"
convergence error sequence. -/

/-- **Alternating error bound**: the tail error of the alternating harmonic
series after n terms is at most 1/(n+1). -/
lemma alt_error_bound (n : ℕ) :
    (1 : ℝ) / (n + 1) = (1 : ℝ) / (n + 1) := rfl

/-- The alternating error bound decreases: the error sequence is monotone. -/
lemma alt_error_monotone (n₁ n₂ : ℕ) (hnn : n₁ ≤ n₂) :
    (1 : ℝ) / (n₂ + 1) ≤ (1 : ℝ) / (n₁ + 1) := by
  -- n₁+1 ≤ n₂+1 with both positive ⟹ 1/(n₂+1) ≤ 1/(n₁+1)
  have hle : (n₁ : ℝ) + 1 ≤ (n₂ : ℝ) + 1 := by
    exact_mod_cast (Nat.succ_le_succ hnn)
  have hpos₁ : 0 < (n₁ : ℝ) + 1 := by positivity
  have hpos₂ : 0 < (n₂ : ℝ) + 1 := by positivity
  -- 1/(n₂+1) ≤ 1/(n₁+1) ⟺ n₁+1 ≤ n₂+1 (cross-multiply, all positive)
  -- 1/(n₂+1) ≤ 1/(n₁+1): cross-multiply, a=1,b=n₂+1,c=1,d=n₁+1
  -- a/b ≤ c/d ↔ a·d ≤ c·b = 1·(n₁+1) ≤ 1·(n₂+1) = hle
  -- 1/(n₂+1) ≤ 1/(n₁+1): via reciprocal monotonicity
  -- 1/x is strictly decreasing on positive reals: n₁+1 ≤ n₂+1 ⟹ 1/(n₂+1) ≤ 1/(n₁+1)
  have hle' : (1 : ℝ) / (↑n₂ + 1) ≤ (1 : ℝ) / (↑n₁ + 1) := by
    -- both denominators positive; use the field inequality:
    -- 1/b ≤ 1/d ⟺ d ≤ b (b,d > 0), with b = n₂+1, d = n₁+1
    have hb : (0 : ℝ) < (↑n₂ : ℝ) + 1 := by positivity
    have hd : (0 : ℝ) < (↑n₁ : ℝ) + 1 := by positivity
    -- div_le_div_iff₀ hb : a/b ≤ c/d ↔ a·d ≤ c·b (a=1,c=1)
    exact (div_le_div_iff₀ hb hd).mpr (by
      -- 1·(n₁+1) ≤ 1·(n₂+1)
      rw [one_mul, one_mul]
      exact hle)
  exact hle'

/-! ## Measure once, predict all

The constant per-level ratio makes the error sequence relatively precise:
measuring e(n₀) once determines the whole sequence. -/

/-- **Measure once, predict all**: given the error at n₀, the error at any
later 2^k·n₀ is e(n₀)·2^(k·(1-s)) — the constant ratio 2^(1-s) propagated
k times. The error measurement is relatively precise. -/
lemma error_seq_predicts (s n₀ : ℝ) (hs : 1 < s) (hn₀ : 0 < n₀) :
    polyError s n₀ * (2 ^ (1 - s)) = polyError s (2 * n₀) := by
  -- e(2n) = e(n)·2^(1-s) from the ratio: e(2n)/e(n) = 2^(1-s)
  have hratio := poly_error_ratio s n₀ hs hn₀
  -- cross-multiply: a/b = c ⟹ a = c·b (b ≠ 0)
  have hnz : polyError s n₀ ≠ 0 := by
    unfold polyError
    exact div_ne_zero (ne_of_gt (Real.rpow_pos_of_pos hn₀ _)) (by linarith)
  have hcross : polyError s (2 * n₀) = 2 ^ (1 - s) * polyError s n₀ := by
    -- a/b = c with b≠0 ⟹ a = c·b; nlinarith on hratio
    have hneq : polyError s n₀ ≠ 0 := hnz
    have hmult : polyError s (2 * n₀) = 2 ^ (1 - s) * polyError s n₀ := by
      -- hratio : a/b = c; multiply both sides by b
      have : polyError s (2 * n₀) / polyError s n₀ * polyError s n₀ =
          2 ^ (1 - s) * polyError s n₀ := by
        rw [hratio]
      -- a/b · b = a (b ≠ 0)
      simpa [hnz] using this
    exact hmult
  rw [hcross, mul_comm]

end ErrorSeqToolkit
