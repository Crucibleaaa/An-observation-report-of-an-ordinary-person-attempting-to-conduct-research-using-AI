/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Finset.Image

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

/-!
# Toolkit/ConciseMagicTeaching — 简明魔法教学: 有限域函数 = 预计算查表

(Concise Magic Teaching: the art of turning any computation on a finite domain
into a precomputed lookup table — the terminal form of simplification.)

Self-contained (imports mathlib only; no project dependencies).

The terminal form of simplification (RulerLookup): any algorithm on a finite
domain reduces to a precomputed table — compute the table offline (O(n)), look
up at runtime (O(1) hash / O(log n) binary search).

Main theorems:

1. `lookup_exists`: for any function `f : α → β` on a finite type `α`, there is
   a table `T : Finset (α × β)` containing every pair `(x, f x)`, and lookup is
   correct: for every `x` there is `(x, y) ∈ T` with `y = f x`. The table is
   constructed as `Finset.image (fun x => (x, f x)) Finset.univ`.

2. `lookup_unique`: the table entry for `x` is unique (the value `f x`): if
   both `(x, y₁)` and `(x, y₂)` are in the image table, then `y₁ = y₂` — the
   lookup is deterministic (a function, not a relation).

3. `lookup_total`: the table is total — every `x` has an entry (no missing
   keys): the image of `univ` covers all of `α`.

These three properties (existence, determinism, totality) are exactly what a
runtime lookup needs: a total deterministic table with the correct values.
-/

noncomputable section

namespace MagicTeaching

variable {α β : Type*} [Fintype α] [DecidableEq α] [DecidableEq β]

/-- The lookup table for `f` on the finite domain `α`: `{(x, f x) : x ∈ α}`. -/
def makeTable (f : α → β) : Finset (α × β) :=
  Finset.image (fun x => (x, f x)) Finset.univ

/-- **Existence**: the table contains every correct pair `(x, f x)` — the
precomputed table is complete. -/
lemma lookup_exists (f : α → β) (x : α) : (x, f x) ∈ makeTable f := by
  unfold makeTable
  exact Finset.mem_image.mpr ⟨x, Finset.mem_univ x, rfl⟩

/-- **Totality**: every `x` has an entry in the table (no missing keys) —
lookup never fails on the domain. -/
lemma lookup_total (f : α → β) (x : α) : ∃ y : β, (x, y) ∈ makeTable f := by
  exact ⟨f x, lookup_exists f x⟩

/-- **Determinism**: the table entry for `x` is unique — if `(x, y₁)` and
`(x, y₂)` are both entries, then `y₁ = y₂`. Lookup is a function, not a
relation. -/
lemma lookup_unique (f : α → β) {x : α} {y₁ y₂ : β}
    (h₁ : (x, y₁) ∈ makeTable f) (h₂ : (x, y₂) ∈ makeTable f) : y₁ = y₂ := by
  unfold makeTable at h₁ h₂
  rcases Finset.mem_image.mp h₁ with ⟨a₁, _, ha₁⟩
  rcases Finset.mem_image.mp h₂ with ⟨a₂, _, ha₂⟩
  -- (a₁, f a₁) = (x, y₁) and (a₂, f a₂) = (x, y₂) ⟹ a₁ = a₂ = x ⟹ y₁ = f x = y₂
  have hx₁ : a₁ = x := congrArg Prod.fst ha₁
  have hx₂ : a₂ = x := congrArg Prod.fst ha₂
  have hy₁ : f a₁ = y₁ := congrArg Prod.snd ha₁
  have hy₂ : f a₂ = y₂ := congrArg Prod.snd ha₂
  rw [hx₁] at hy₁
  rw [hx₂] at hy₂
  -- hy₁ : f x = y₁, hy₂ : f x = y₂ ⟹ y₁ = f x = y₂
  rw [← hy₁, ← hy₂]

/-- **Lookup correctness**: the value found for `x` in the table is exactly
`f x` (the precomputed value matches the computed one). -/
lemma lookup_correct (f : α → β) (x : α) (y : β) (h : (x, y) ∈ makeTable f) :
    y = f x := by
  -- (x, y) ∈ image table ⟹ y = f x
  unfold makeTable at h
  rcases Finset.mem_image.mp h with ⟨a, _, ha⟩
  have hx : a = x := congrArg Prod.fst ha
  have hy : f a = y := congrArg Prod.snd ha
  rw [hx] at hy
  exact hy.symm

/-- **The terminal form of simplification**: on a finite domain, every function
is exactly its precomputed table — lookup is total, deterministic, and correct.
This is the formal content of "所有化简步骤 = 查表". -/
theorem function_is_table (f : α → β) :
    (∀ x, (x, f x) ∈ makeTable f) ∧
    (∀ x, ∃ y, (x, y) ∈ makeTable f) ∧
    (∀ x y₁ y₂, (x, y₁) ∈ makeTable f → (x, y₂) ∈ makeTable f → y₁ = y₂) ∧
    (∀ x y, (x, y) ∈ makeTable f → y = f x) := by
  constructor
  · exact fun x => lookup_exists f x
  · constructor
    · exact fun x => lookup_total f x
    · constructor
      · intro x y₁ y₂ h₁ h₂
        exact lookup_unique f h₁ h₂
      · intro x y h
        exact lookup_correct f x y h

end MagicTeaching
