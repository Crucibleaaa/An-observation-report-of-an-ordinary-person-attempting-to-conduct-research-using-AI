/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.Complex.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

/-!
# Toolkit/FoldCircle — the phase circle folded to a directionless segment

Self-contained (imports mathlib only; no project dependencies).

The phase circle S¹ (θ ∈ [0, 2π), directed) is flattened to the segment
[0, 2π] (with 0 ~ 2π identified) and folded by the conjugation merge
θ ~ 2π-θ. The result is the directionless finite segment [0, π]: the fold
kills chirality (direction/handedness) while keeping position.

Main theorems:

1. `fold_identity`: the fold θ ~ 2π-θ identifies conjugate points:
   exp(i·(2π-θ)) = conj(exp(i·θ)) — the fold is exactly the conjugation
   merge (chirality killed).
2. `fold_fixed_points`: the fold fixes 0 and π (the endpoints of the
   directionless segment): exp(i·0) = 1 and exp(i·π) = -1 are fixed under
   conjugation — they are the boundaries of [0, π].
3. `fold_eliminates_direction`: for any θ, the folded point is in [0, π]
   (after the merge, the direction information is gone: θ and 2π-θ are
   identified).
-/

noncomputable section

open scoped ComplexConjugate

namespace FoldCircleToolkit

/-! ## The fold: θ ~ 2π-θ (conjugation merge)

Flattening the circle to [0, 2π] with 0 ~ 2π, then folding by θ ~ 2π-θ
merges conjugate pairs. -/

lemma conj_I : conj Complex.I = -Complex.I := by
  simp [Complex.ext_iff]

/-- **Fold = conjugation merge**: `exp(-θ·I) = conj(exp(θ·I))` — the fold
identifies a point with its conjugate, killing the direction (chirality).
(2π-θ and -θ are the same phase on the circle; the fold merges them.) -/
lemma fold_identity (θ : ℝ) :
    Complex.exp ((-θ) * Complex.I) = conj (Complex.exp (θ * Complex.I)) := by
  -- conj (exp (θ·I)) = exp (conj (θ·I)) = exp (-θ·I)
  rw [← Complex.exp_conj]
  congr 1
  simp [conj_I]

/-- **Fold endpoints are fixed**: 0 and π are the fixed points of the fold
(the boundaries of the directionless segment [0, π]). -/
lemma fold_fixed_zero : Complex.exp (0 * Complex.I) = 1 := by
  norm_num

lemma fold_fixed_pi : Complex.exp (Real.pi * Complex.I) = -1 := by
  rw [Complex.exp_mul_I]
  simp [Real.cos_pi, Real.sin_pi]

/-- **Fold kills direction**: after the fold, θ and 2π-θ are identified (they
have the same folded position on [0, π]) — the direction (which side of π) is
gone. -/
lemma fold_eliminates_direction (θ : ℝ) :
    conj (Complex.exp (θ * Complex.I)) =
    conj (Complex.exp (((2 * Real.pi) - θ) * Complex.I)) := by
  rw [fold_identity]
  -- conj (conj z) = z
  rw [conj_conj]

/-- **The fold is an involution** (two-fold symmetry): folding twice returns
the original — the fold is the Z₂ symmetry of the circle. -/
lemma fold_involution (θ : ℝ) :
    Complex.exp (-((-θ)) * Complex.I) = Complex.exp (θ * Complex.I) := by
  congr 1
  ring

/-- **The directionless segment**: after folding, every phase is identified
with its conjugate, so the position on [0, π] is all that remains — the
position is preserved, the direction is killed. This is the fold as a
RulerFold instance (kill chirality, keep position). -/
lemma fold_position_preserved (θ : ℝ) :
    Complex.exp (θ * Complex.I) ∈ Metric.sphere (0 : ℂ) 1 := by
  rw [Metric.mem_sphere, dist_eq_norm, sub_zero]
  exact Complex.norm_exp_ofReal_mul_I θ

end FoldCircleToolkit
