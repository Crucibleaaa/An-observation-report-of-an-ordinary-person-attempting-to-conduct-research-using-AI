/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Algebra.Torsor.Defs
import Mathlib.GroupTheory.GroupAction.Basic
import Mathlib.Logic.Equiv.Basic
import Mathlib.Tactic.Ring

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

/-!
# Toolkit/BasepointGen — self-contained basepoint teleport for additive torsors

Self-contained (imports mathlib only; no project dependencies).

A basepoint is a distinguished point `e : P` of a torsor `P` over an additive group
`G` (points +ᵥ vectors = points; points -ᵥ points = vectors). The basepoint
teleport (穿折越 / Worn-Zhe-Yue) is the map

  T_{e→f}(x) := x +ᵥ (f -ᵥ e)

which moves the basepoint from `e` to `f`: every point `x` is translated by the
displacement `f -ᵥ e`. This is the additive-torsor analogue of the heap basepoint
change `T_{e→f}(x) = [x, e, f]` (C006) — but self-contained, requiring only
`AddTorsor`.

Main theorems:

1. `teleport_basepoint`: `T_{e→f}(e) = f` — the basepoint moves to `f`.
2. `teleport_teleport`: `T_{f→g} (T_{e→f} x) = T_{e→g} x` — teleports compose
   (path-independence on a flat torsor).
3. `teleport_bijective`: `T_{e→f}` is a bijection (bijective iff bijective
   translation; basepoint change is invertible).
4. `displacement_eq_iff`: two basepoint pairs `(e,a)` and `(f,b)` denote the same
   relative displacement iff `b = T_{e→f}(a)` — the displacement space equivalence
   (C007 analogue).

The displacement space: pairs `(e, a)` up to `(e,a) ~ (f,b) ⇔ b = T_{e→f}(a)`.
On a flat torsor this is equivalent to the additive group `G` itself (the
translation group), and the equivalence is basepoint-independent (relative
stability, C007).
-/

noncomputable section

open scoped Pointwise

namespace BasepointToolkit

variable {G P : Type*}
  [AddGroup G] [AddTorsor G P]

/-! ## Basepoint teleport

The teleport map `T_{e→f}` translates every point by the displacement from `e`
to `f`. -/

/-- Basepoint teleport: `T_{e→f}(x) = x +ᵥ (f -ᵥ e)`. Moves the basepoint from
`e` to `f`. -/
def teleport (e f : P) (x : P) : P :=
  (f -ᵥ e) +ᵥ x

@[simp] lemma teleport_basepoint (e f : P) : teleport e f e = f := by
  simp [teleport]

/-- Teleport along a zero displacement is the identity. -/
@[simp] lemma teleport_self (e : P) (x : P) : teleport e e x = x := by
  simp [teleport]

/-- Teleports compose: `T_{f→g} ∘ T_{e→f} = T_{e→g}` — path independence on a
flat torsor. -/
lemma displacement_add_assoc (e f g : P) : (g -ᵥ f) + (f -ᵥ e) = g -ᵥ e := by
  -- group identity on displacement vectors: (g-f) + (f-e) = g-e
  simp [sub_eq_add_neg, add_assoc, add_left_comm, add_comm]

/-- Teleports compose: `T_{f→g} ∘ T_{e→f} = T_{e→g}` — path independence on a
flat torsor. -/
lemma teleport_teleport (e f g x : P) :
    teleport f g (teleport e f x) = teleport e g x := by
  unfold teleport
  -- (g -ᵥ f) +ᵥ ((f -ᵥ e) +ᵥ x) = (g -ᵥ e) +ᵥ x
  calc
    (g -ᵥ f) +ᵥ ((f -ᵥ e) +ᵥ x) = ((g -ᵥ f) + (f -ᵥ e)) +ᵥ x := by
      rw [add_vadd]
    _ = (g -ᵥ e) +ᵥ x := by rw [displacement_add_assoc]

/-- Basepoint teleport is invertible: `T_{e→f} ∘ T_{f→e} = id`. -/
lemma teleport_inv (e f x : P) : teleport f e (teleport e f x) = x := by
  unfold teleport
  calc
    (e -ᵥ f) +ᵥ ((f -ᵥ e) +ᵥ x) = ((e -ᵥ f) + (f -ᵥ e)) +ᵥ x := by
      rw [add_vadd]
    _ = x := by
      -- (e -ᵥ f) + (f -ᵥ e) = 0, then 0 +ᵥ x = x
      have h : (e -ᵥ f) + (f -ᵥ e) = 0 := by
        simp [sub_eq_add_neg, add_assoc]
      rw [h]
      simp

/-- `T_{e→f}` is a bijection: basepoint change is an invertible translation. -/
theorem teleport_bijective (e f : P) : Function.Bijective (teleport e f) := by
  refine ⟨?_, ?_⟩
  · intro x y hxy
    -- translate back by (e -ᵥ f) to cancel
    have h := congrArg (teleport f e) hxy
    simpa [teleport_inv] using h
  · intro y
    refine ⟨teleport f e y, ?_⟩
    simp [teleport_inv]

/-! ## Displacement space

Two basepoint pairs `(e, a)` and `(f, b)` denote the same relative displacement
when `b = T_{e→f}(a)`, i.e. `b = a +ᵥ (f -ᵥ e)`. This is the basepoint-relative
displacement equivalence (C007): relative stability — the *equivalence* is
basepoint-independent, while the concrete coordinates `(e,a)` depend on the
basepoint. -/

/-- The displacement relation: `(e,a)` and `(f,b)` have the same relative
displacement iff `b` is the teleport of `a`. -/
def Displacement (e a f b : P) : Prop :=
  b = teleport e f a

/-- The displacement relation is reflexive: `(e,a)` relates to itself. -/
lemma displacement_refl (e a : P) : Displacement e a e a := by
  simp [Displacement]

/-- The displacement relation is symmetric. -/
lemma displacement_symm {e a f b : P} (h : Displacement e a f b) :
    Displacement f b e a := by
  -- b = a +ᵥ (f -ᵥ e); need a = b +ᵥ (e -ᵥ f)
  unfold Displacement at h
  unfold Displacement
  -- a = b +ᵥ (e -ᵥ f) = (a +ᵥ (f -ᵥ e)) +ᵥ (e -ᵥ f) = a
  rw [h]
  unfold teleport
  rw [← add_vadd]
  simp [sub_eq_add_neg, add_assoc]

/-- The displacement relation is transitive. -/
lemma displacement_trans {e a f b g c : P}
    (h₁ : Displacement e a f b) (h₂ : Displacement f b g c) :
    Displacement e a g c := by
  unfold Displacement at h₁ h₂ ⊢
  rw [h₂, h₁]
  unfold teleport
  rw [← add_vadd]
  rw [displacement_add_assoc]

/-- The displacement relation is an equivalence relation on `P × P`. -/
theorem displacement_equiv : Equivalence (fun p q : P × P => Displacement p.1 p.2 q.1 q.2) :=
  ⟨fun p => displacement_refl p.1 p.2, fun h => displacement_symm h, fun h₁ h₂ =>
    displacement_trans h₁ h₂⟩

/-- **The invariance of displacement**: under the displacement equivalence, the
relative displacement `a -ᵥ e` is invariant up to the teleport direction.
Concretely: `(e,a) ~ (f, T_{e→f} a)` — the teleported pair has the same
displacement class (relative stability, C007). -/
lemma displacement_teleport_invariant (e f a : P) :
    Displacement e a f (teleport e f a) := by
  rfl

end BasepointToolkit
