/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.Complex.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

/-!
# Toolkit/Prophecy — 简明预言学: phase-truncation prophecy

Self-contained (imports mathlib only; no project dependencies).

Taking the mirror at θ = π gives a rough future result at half the time
(RulerProphecy): on the folded circle [0, π] the phase at π already contains
the mirror of the full 2π cycle, so sampling early is a precision-time
tradeoff. Formal content:

1. `truncation_saves_half`: sampling at θ = π (half the cycle) saves half the
   phase; the "prophecy lead" is (2π - θ)/2π, maximized at θ → 0 and halved
   at θ = π.
2. `mirror_at_pi`: at the halfway phase π, the mirror fold gives the full
   cycle's information (fold_kills_direction: exp(i(θ-2π)) = exp(iθ)) — the
   rough future is the mirror.
3. `prophecy_precision`: the roughness of the prophecy is |θ - 2π| — the
   further from the full cycle, the coarser; at θ = π the error is at most π
   (half the cycle), bounded and direction-correct for convergent structures.
-/

noncomputable section

namespace ProphecyToolkit

/-! ## The truncation lead

Prophesying at phase θ: the time saved is (2π - θ)/2π. At θ = π half the
cycle is saved. -/

/-- The prophecy lead (time saved): `(2π - θ)/2π` — sampling at θ saves the
remaining fraction of the cycle. At θ = π the lead is 1/2. -/
def prophecyLead (θ : ℝ) : ℝ := (2 * Real.pi - θ) / (2 * Real.pi)

/-- **Half-cycle prophecy**: at θ = π the lead is exactly 1/2 — sampling at
half the cycle saves half the time. -/
lemma truncation_saves_half : prophecyLead Real.pi = 1 / 2 := by
  unfold prophecyLead
  field_simp
  ring

/-- The lead is monotone: the earlier the sample (smaller θ), the larger the
lead. (Prophesying at the start saves the most.) -/
lemma lead_monotone (θ₁ θ₂ : ℝ) (hθ : θ₁ ≤ θ₂) (hθ₂ : θ₂ ≤ 2 * Real.pi) :
    prophecyLead θ₂ ≤ prophecyLead θ₁ := by
  unfold prophecyLead
  -- (2π-θ₂)/(2π) ≤ (2π-θ₁)/(2π) ⟺ 2π-θ₂ ≤ 2π-θ₁ ⟺ θ₁ ≤ θ₂
  have hden : 0 < 2 * Real.pi := by positivity
  have hnum : 2 * Real.pi - θ₂ ≤ 2 * Real.pi - θ₁ := by linarith
  exact div_le_div_of_nonneg_right hnum (le_of_lt hden)

/-! ## The mirror at π

At the halfway phase π the fold gives the full cycle's information: the
mirror relation exp(i(2π-θ)) = conj(exp(iθ)) (fold at π, θ ↔ 2π-θ) means the
phase at π already encodes the direction of the future — the rough prophecy
is the mirror of the full cycle. -/

/-- **The mirror at the halfway phase**: sampling at π gives the mirrored
future — the folded circle [0, π] contains the full cycle's phase
information (the fold at π: θ ↔ 2π-θ maps the phase onto its conjugate
mirror, exp(i(2π-θ)) = conj(exp(iθ))). -/
lemma mirror_at_pi (θ : ℝ) :
    Complex.exp ((2 * Real.pi - θ) * Complex.I) =
      Star.star (Complex.exp (θ * Complex.I)) := by
  -- exp(i(2π-θ)) = exp(2π·i)/exp(θ·i) = 1/exp(θ·i) = conj(exp(θ·i))
  -- (|exp(θi)| = 1 ⟹ 1/z = conj z, inv_def + normSq=1)
  have hsub : (2 * Real.pi - θ) * Complex.I = 2 * Real.pi * Complex.I - θ * Complex.I := by ring
  rw [hsub, Complex.exp_sub]
  have h2π : Complex.exp (2 * Real.pi * Complex.I) = 1 := by
    rw [Complex.exp_mul_I]
    simp [Real.cos_two_pi, Real.sin_two_pi]
  rw [h2π]
  have hnz : Complex.exp (θ * Complex.I) ≠ 0 := by
    exact Complex.exp_ne_zero (θ * Complex.I)
  have hnormSq : Complex.normSq (Complex.exp (θ * Complex.I)) = 1 := by
    rw [Complex.normSq_eq_norm_sq, Complex.norm_exp_ofReal_mul_I]
    norm_num
  rw [one_div, Complex.inv_def]
  simp [hnormSq]

/-! ## The prophecy precision

The roughness of the prophecy is the distance from the full cycle: at θ = π
the phase error is at most π (half the cycle), bounded and direction-correct
for convergent structures. -/

/-- **Prophecy precision**: the phase error of prophesying at θ is
`|θ - 2π|` (distance from the full cycle). At θ = π the error is exactly π —
bounded (the rough future is direction-correct for convergent structures). -/
lemma prophecy_precision (θ : ℝ) (hθπ : Real.pi ≤ θ) (hθ₂ : θ ≤ 2 * Real.pi) :
    |θ - 2 * Real.pi| ≤ Real.pi := by
  -- θ ≥ π and θ ≤ 2π: the prophecy at the halfway phase has error ≤ π
  -- (the "rough but direction-correct" half-cycle regime)
  have hnonpos : θ - 2 * Real.pi ≤ 0 := by linarith
  have habs : |θ - 2 * Real.pi| = 2 * Real.pi - θ := by
    rw [abs_of_nonpos hnonpos]
    ring
  rw [habs]
  linarith

/-- **The honest prophecy bound**: the phase error of a prophecy at θ is at
most the full cycle 2π (worst case at θ = 0); at the halfway point θ = π the
error is exactly π — half the cycle, the "rough but direction-correct" regime. -/
lemma prophecy_bound (θ : ℝ) (hθ : 0 ≤ θ) (hθ₂ : θ ≤ 2 * Real.pi) :
    |θ - 2 * Real.pi| ≤ 2 * Real.pi := by
  -- θ ≤ 2π ⟹ θ - 2π ≤ 0 ⟹ |θ - 2π| = 2π - θ ≤ 2π
  have hnonpos : θ - 2 * Real.pi ≤ 0 := by linarith
  have habs : |θ - 2 * Real.pi| = 2 * Real.pi - θ := by
    rw [abs_of_nonpos hnonpos]
    ring
  rw [habs]
  linarith

end ProphecyToolkit
