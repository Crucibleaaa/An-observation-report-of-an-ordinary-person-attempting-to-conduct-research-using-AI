/-
Copyright (c) 2026 The Author(s). All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: anonymous
-/
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Data.Real.Basic
import Mathlib.Data.Complex.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

/-!
# Toolkit/AxisComponent — single-axis component transformations (finite types)

Self-contained (imports mathlib only; no project dependencies).

The "infinite components" of a structure reduce to a finite number of
transformation *types*, each preserving symmetry and varying only a parameter.
Three single-axis component types (用户 2026-08-12 指令):

1. **Iteration count** (类型①: 迭代次数, 均匀张缩): multiplication is iteration
   of addition (`n * a = a + ... + a`), exponentiation is iteration of
   multiplication (`a ^ n = a * ... * a`). The parameter is the count `n`.

2. **Angle** (类型②: 夹角, projection): an irrational number is the projection
   of an integer along a slanted axis: `√2 = 2·cos 45°`, `√3 = 2·cos 30°`.
   The parameter is the angle `θ`.

3. **Symmetry preservation** (类型③: 对称保持): rotations/reflections preserve
   the invariant (`‖z‖ = 1` on the unit circle); only the angle varies.

Main theorems:

- `mul_eq_sum_iterate`: multiplication is iteration of addition
  (`n * a = ∑ i in Finset.range n, a` for n : ℕ).
- `pow_eq_mul_iterate`: exponentiation is iteration of multiplication
  (`a ^ n = ∏ i in Finset.range n, a`).
- `log_pow_mul`: the logarithm extracts the iteration count:
  `log (a ^ n) = n * log a` (the count becomes visible).
- `cos_sq_add_sin_sq`: the angle projection satisfies cos²θ + sin²θ = 1
  (the unit-circle invariant, symmetry preserved under any angle).
- `norm_exp_I_eq_one`: rotations preserve the invariant `‖exp(θ·I)‖ = 1`
  for every angle θ (symmetry type: parameter varies, invariant fixed).

These are the three single-axis components; every further component is a
parameter combination of these, not a new type.
-/

noncomputable section

open scoped BigOperators

namespace AxisToolkit

/-! ## 类型①: Iteration count (均匀张缩)

Multiplication is iteration of addition; exponentiation is iteration of
multiplication. The parameter is the count `n`. -/

/-- Multiplication is iteration of addition: `n * a = a + a + ... + a` (n times). -/
lemma mul_eq_sum_iterate {R : Type*} [Semiring R] (a : R) (n : ℕ) :
    (n : R) * a = Finset.sum (Finset.range n) (fun _ => a) := by
  -- n * a = a + a + ... + a (n terms); classic: Finset.sum_const
  rw [Finset.sum_const, nsmul_eq_mul]
  simp

/-- Exponentiation is iteration of multiplication: `a ^ n = a * a * ... * a`. -/
lemma pow_eq_prod_iterate {R : Type*} [CommMonoid R] (a : R) (n : ℕ) :
    a ^ n = Finset.prod (Finset.range n) (fun _ => a) := by
  induction n with
  | zero =>
      simp
  | succ n ih =>
      simp [Finset.prod_range_succ, ih]

/-- The logarithm extracts the iteration count: `log (a ^ n) = n * log a`.
The count `n` (the parameter of the iteration type) becomes directly visible. -/
lemma log_pow_mul (a : ℝ) (n : ℕ) :
    Real.log (a ^ n) = (n : ℝ) * Real.log a := by
  rw [Real.log_pow]

/-! ## 类型②: Angle (投影, 夹角)

An irrational number is the projection of an integer along a slanted axis at
angle θ: `n·cos θ` on the real axis. The parameter is the angle θ. -/

/-- The angle projection satisfies the unit invariant: cos²θ + sin²θ = 1
(the projection components span the unit circle, independent of θ). -/
lemma cos_sq_add_sin_sq (θ : ℝ) : Real.cos θ ^ 2 + Real.sin θ ^ 2 = 1 := by
  exact Real.cos_sq_add_sin_sq θ

/-! ## 类型③: Symmetry preservation (对称保持)

Rotations preserve the invariant `‖z‖ = 1` on the unit circle; only the angle
varies. The symmetry is unchanged; the parameter (angle) changes. -/

/-- Rotations preserve the unit invariant: `‖exp(θ·I)‖ = 1` for every angle θ.
Symmetry type: parameter varies, invariant fixed. -/
lemma norm_exp_I_eq_one (θ : ℝ) : ‖Complex.exp (θ * Complex.I)‖ = 1 := by
  exact Complex.norm_exp_ofReal_mul_I θ

/-- The invariant is independent of the angle: the symmetry is preserved under
any rotation. This is the "对称性不变, 只变夹角" principle. -/
lemma invariant_independent_of_angle (θ₁ θ₂ : ℝ) :
    ‖Complex.exp (θ₁ * Complex.I)‖ = ‖Complex.exp (θ₂ * Complex.I)‖ := by
  rw [norm_exp_I_eq_one, norm_exp_I_eq_one]

/-- The three component types are parameterized, not enumerated: the iteration
count `n`, the angle `θ`, and the invariant `‖z‖ = 1` are the parameters of the
three finite transformation types. -/
lemma three_types_parameterized (n : ℕ) (a θ : ℝ) :
    (n : ℝ) * a = Finset.sum (Finset.range n) (fun _ => a) ∧
    Real.cos θ ^ 2 + Real.sin θ ^ 2 = 1 ∧
    ‖Complex.exp (θ * Complex.I)‖ = 1 := by
  constructor
  · exact mul_eq_sum_iterate a n
  · constructor
    · exact cos_sq_add_sin_sq θ
    · exact norm_exp_I_eq_one θ

end AxisToolkit

/-! ## 自由度轴 (RulerAxis 层4): 2^k 序列

The degrees-of-freedom axis: the reduction chain 8→4→2→1 is the sequence
`2^k` for k = 3,2,1,0 — the discrete levels of the degree-of-freedom axis.
Each level's successor divides by 2 (k ↦ k-1). -/

/-- The degree-of-freedom level: `2^k` (the discrete scale of the dof axis). -/
def dofLevel (k : ℕ) : ℕ := 2 ^ k

/-- The dof axis's successor structure: `dofLevel (k+1) = 2 * dofLevel k` —
each level is half of the next (the reduction chain 8→4→2→1 steps by dividing
by 2). -/
lemma dofLevel_succ (k : ℕ) : dofLevel (k + 1) = 2 * dofLevel k := by
  unfold dofLevel
  rw [pow_succ]
  rw [mul_comm]

/-- The dof axis is discrete: 2^k is a power of two at every level (the
reduction chain is exactly the dof axis traversed downward). -/
lemma dofLevel_pow_two (k : ℕ) : dofLevel k = 2 ^ k := rfl
